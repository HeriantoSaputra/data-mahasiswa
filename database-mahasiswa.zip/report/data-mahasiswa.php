<?php
session_start();
include '../config/koneksi.php';
$tgl_awal  = $_GET['tgl_awal'];
$tgl_akhir = $_GET['tgl_akhir'];
?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<img src="../foto/agent.png" width="150px">
<table class="table  table-bordered">	
<tr >
	<th>No</th>
	<th>Nama</th>
	<th>Nim</th>
	<th>Gender</th>
	<th>Nilai</th>
	<th>Date Input</th>
	
</tr>
<?php
$no = 0;
$query = mysqli_query($mysqli, "SELECT * FROM tb_mahasiswa WHERE SUBSTR(waktu_input,1,10) between '$tgl_awal' AND '$tgl_akhir'");
while($result=mysqli_fetch_array($query)){
	$no++
	?>

<tr>	
	<td><?php echo $no;?></td>
	<td><?php echo $result['nama'];?></td>
	<td align="center"><?php echo $result['nim'];?></td>
	<td align="center"><?php echo $result['gender'];?></td>
	<td><?php echo $result['nilai'];?></td>
	<td><?php echo $result['waktu_input'];?></td>
	
</tr>	


<?php }
?>
</table>
<!-- <script>
	window.print();
</script> -->