<?php
include 'koneksi.php';

$hapus = mysqli_query($mysqli,"INSERT INTO tb_mahasiswa (id) values('')");
header('Location: data-mahasiswa.php');
exit;
?>