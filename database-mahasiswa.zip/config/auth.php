<?php
session_start();
include 'koneksi.php';
$username = $_POST['username'];
$password = $_POST['password'];

$_SESSION['username'] = $_POST['username'];

//echo $username.'</br>';
//echo $password;
$query = mysqli_query($mysqli,"SELECT * from tb_mahasiswa where nama = '$username' and nim = '$password' ");
$result = mysqli_num_rows($query);

if($result > 0){
    header("location:../home.php");
}
else{
    header("location:../index.php?pesan=error");
}
?>