<?php
include 'config/koneksi.php';
//echo $_POST['nama'];
$id     =  $_POST['id'];
$nama   =  $_POST['nama'];
$nim    =  $_POST['nim'];
$gender =  $_POST['gender'];

$hapus = mysqli_query($mysqli,"UPDATE tb_mahasiswa SET 
                                        nama = '$nama', 
                                        nim  = '$nim',
                                        gender = '$gender'
                                        where id = '$id'");
header('Location: home.php');
exit;
?>