<?php
session_start();
if(!$_SESSION['username']){
	header("location:index.php?pesan=sesion_habis");
}
include 'config/koneksi.php';
?>
<style>
button{background-color:dodgerblue; color:white; }
</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<form method="get" action="report/data-mahasiswa.php">
<input type="date" value="<?php echo date('Y-m-d');?>" name="tgl_awal"> s/d<input type="date" name="tgl_akhir">
<a  class='tombol' href="tambah-data.php"><button>Cari</button></a></br>

</form>
<a href="create-data.php" class='tombol' href="tambah-data.php"><button>Tambah data</button></a>
<table class="table  table-bordered">	
<tr >
	<th>No</th>
	<th>Nama</th>
	<th>Nim</th>
	<th>Gender</th>
	<th>Nilai</th>
	<th>Date Input</th>
	<th>Action</th>
</tr>
<?php
$no = 0;
$query = mysqli_query($mysqli, "SELECT * FROM tb_mahasiswa");
while($result=mysqli_fetch_array($query)){
	$no++
	?>

<tr>	
	<td><?php echo $no;?></td>
	<td><?php echo $result['nama'];?></td>
	<td align="center"><?php echo $result['nim'];?></td>
	<td align="center"><?php echo $result['gender'];?></td>
	<td><?php echo $result['nilai'];?></td>
	<td><?php echo $result['waktu_input'];?></td>
	<td>
		<a href="form-edit.php?id=<?php echo $result['id'];?>">Edit</a>
		<a href="hapus_data.php?id=<?php echo $result['id'];?>">Delete</a>
	</td>
</tr>	


<?php }
?>
</table>
<a class="tombol" style="float:right;" href="index.php"><button>Logout</button></a>