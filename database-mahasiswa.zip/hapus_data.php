<?php
include 'config/koneksi.php';
$id =  $_GET['id'];

$hapus = mysqli_query($mysqli,"delete from tb_mahasiswa where id = '$id'");
header('Location: home.php');
exit;
?>