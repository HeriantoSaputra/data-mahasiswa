<?php
include 'config/koneksi.php';
$id = $_GET['id'];
$query = mysqli_query($mysqli, "SELECT * FROM tb_mahasiswa WHERE id ='$id'");
$result= mysqli_fetch_array($query);
?>
<form method="post" action="edit_data.php">
Nama Lengkap : <input name="nama" value="<?php echo $result['nama'];?>"></br>
NIM : <input name="nim" value="<?php echo $result['nim'];?>"></br>
Gender : <select name="gender">
            <option value="<?php echo $result['nim'];?>"><?php echo $result['nim'];?></option>            
            <option value="L">L</option>
            <option value="P">P</option>
        </select></br>   
<input name="id" value="<?php echo $id;?>" hidden>
<input type="file">
<button type="submit">Simpan</button>
</form>