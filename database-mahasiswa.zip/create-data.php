<?php
include 'config/koneksi.php';
$query = mysqli_query($mysqli, "INSERT INTO tb_mahasiswa (id) VALUES('')");
header("location:home.php");
?>